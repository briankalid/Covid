import json

def lambda_handler(event, context):
    # Maneja el evento
    print("Evento recibido: " + json.dumps(event))
    # Realiza alguna acción, como procesar el archivo subido
    # Puedes acceder a los detalles del evento para obtener información sobre el archivo subido
